#!/bin/bash
mono GitExtensions.exe "$@" &